nullSpace v0.9.94-beta - Portable Version
=========================================

This is a portable version of nullSpace that doesn't require installation.

To run:
1. Extract all files to any folder
2. Run nullSpace.exe
3. Your settings and projects will be stored in the same folder

Version: 0.9.94-beta
Build Date: 2025-10-17

For more information, visit: https://github.com/mendelsonvfx
