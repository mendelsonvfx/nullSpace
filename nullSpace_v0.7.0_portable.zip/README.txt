nullSpace v0.7.0-beta - Portable Version
