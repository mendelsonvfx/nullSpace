nullSpace v0.9.0-beta - Portable Version
========================================

This is a portable version of nullSpace that doesn't require installation.

To run:
1. Extract all files to any folder
2. Run nullSpace.exe
3. Your settings and projects will be stored in the same folder

Features:
- Project management for Blender, Houdini, and After Effects
- Thumbnail generation and caching
- Custom project categories and tags
- Markdown notes support
- Dark theme interface

Version: 0.9.0-beta
Build Date: 2025-10-10

For more information, visit: https://github.com/mendelsonvfx
